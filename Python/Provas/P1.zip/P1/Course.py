class Course:
    def __init__(self, name, studyArea):
        self.name = name
        self.studyArea = studyArea