class Student:
    def __init__(self, name, age, cpf):
        self.name = name
        self.age = age
        self.cpf = cpf